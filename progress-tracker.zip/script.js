// 🔐 Simple password protection
const password = "myprogress2025";
if (prompt("Enter password to access your progress tracker:") !== password) {
  alert("Incorrect password.");
  document.body.innerHTML = "<h2>Access Denied</h2>";
  throw new Error("Access denied");
}

const form = document.getElementById("progressForm");
const list = document.getElementById("progressList");
const categoryInput = document.getElementById("category");

let entries = JSON.parse(localStorage.getItem("progressEntries")) || [];

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const date = document.getElementById("date").value;
  const task = document.getElementById("task").value.trim();
  const category = categoryInput.value;

  if (date && task) {
    entries.push({ date, task, category });
    saveEntries();
    form.reset();
  }
});

function saveEntries() {
  localStorage.setItem("progressEntries", JSON.stringify(entries));
  renderEntries();
  updateCharts();
  updateCalendar();
}

function renderEntries() {
  list.innerHTML = "";
  entries.forEach((entry, index) => {
    const li = document.createElement("li");
    li.innerHTML = `
      <span><strong>${entry.date}</strong> [${entry.category}]: ${entry.task}</span>
      <div class="actions">
        <button class="edit" onclick="editEntry(${index})">Edit</button>
        <button class="delete" onclick="deleteEntry(${index})">Delete</button>
      </div>
    `;
    list.appendChild(li);
  });
}

function editEntry(index) {
  const newTask = prompt("Edit your entry:", entries[index].task);
  if (newTask) {
    entries[index].task = newTask.trim();
    saveEntries();
  }
}

function deleteEntry(index) {
  if (confirm("Are you sure you want to delete this entry?")) {
    entries.splice(index, 1);
    saveEntries();
  }
}

// 📊 Chart.js Setup
let barChart, pieChart;
function updateCharts() {
  const monthCounts = Array(12).fill(0);
  const categoryCounts = { Work: 0, Fitness: 0, Study: 0, Other: 0 };

  entries.forEach(({ date, category }) => {
    const month = new Date(date).getMonth();
    monthCounts[month]++;
    categoryCounts[category]++;
  });

  const barCtx = document.getElementById('barChart').getContext('2d');
  const pieCtx = document.getElementById('pieChart').getContext('2d');

  if (barChart) barChart.destroy();
  if (pieChart) pieChart.destroy();

  barChart = new Chart(barCtx, {
    type: 'bar',
    data: {
      labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
               "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
      datasets: [{
        label: 'Entries per Month',
        data: monthCounts,
        backgroundColor: '#f582ae',
      }]
    }
  });

  pieChart = new Chart(pieCtx, {
    type: 'pie',
    data: {
      labels: Object.keys(categoryCounts),
      datasets: [{
        label: 'Entry Categories',
        data: Object.values(categoryCounts),
        backgroundColor: ['#a3c4f3', '#fef6e4', '#8bd3dd', '#f582ae'],
      }]
    }
  });
}

// 📅 Calendar View
function updateCalendar() {
  const calendar = document.getElementById("calendar");
  calendar.innerHTML = "";

  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const hasEntry = entries.some(e => e.date === dateStr);

    const dayDiv = document.createElement("div");
    dayDiv.textContent = d;
    if (hasEntry) dayDiv.classList.add("active");
    dayDiv.title = dateStr;

    dayDiv.addEventListener("click", () => {
      const dayEntries = entries.filter(e => e.date === dateStr);
      if (dayEntries.length > 0) {
        alert(dayEntries.map(e => `[${e.category}] ${e.task}`).join("\n"));
      }
    });

    calendar.appendChild(dayDiv);
  }
}

// Initial render
renderEntries();
updateCharts();
updateCalendar();
